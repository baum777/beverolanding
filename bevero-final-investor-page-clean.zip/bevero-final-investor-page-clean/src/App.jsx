import React, { useMemo, useState } from "react";

const events = {
  import: {
    title: "FoodNotify-Import",
    subtitle: "Einkauf automatisch erkennen",
    value: 12,
    minutes: 15,
    yearly: 3120,
    message:
      "Eine eingehende Mail oder PDF-Rechnung wird als Rohdaten-Payload gespeichert, normalisiert und in strukturierte Artikelzeilen übersetzt.",
    active: ["foodnotify", "raw", "normalizer", "parsed", "audit"],
    log: [
      "purchase_received",
      "raw_payload_stored",
      "payload_normalized",
      "parsed_line_item_created",
      "audit_event_appended",
    ],
  },
  shortage: {
    title: "Fehlmenge erkannt",
    subtitle: "Bestellt 10, geliefert 8",
    value: 45,
    minutes: 8,
    yearly: 4680,
    message:
      "Eine Differenz bei der Warenannahme wird sofort sichtbar. Der Betrieb kann reklamieren, statt die Abweichung später im Lager zu verlieren.",
    active: ["purchase", "movement", "audit", "roi"],
    log: [
      "delivery_checked",
      "quantity_mismatch_detected",
      "stock_adjustment_created",
      "supplier_claim_needed",
      "audit_event_appended",
    ],
  },
  refill: {
    title: "Bar-Refill erzeugt",
    subtitle: "Mindestbestand unterschritten",
    value: 80.6,
    minutes: 12,
    yearly: 4195,
    message:
      "Ein Mindestbestand wird unterschritten. Die Webapp erzeugt automatisch eine mobile Auffüllaufgabe für Bar oder Küche.",
    active: ["inventory", "location", "movement", "refill", "mobile", "audit", "roi"],
    log: [
      "stock_threshold_checked",
      "refill_task_open",
      "mobile_task_visible",
      "operator_action_required",
      "audit_event_appended",
    ],
  },
};

const modes = {
  ceo: {
    label: "CEO View",
    text: "Kontrolle über Einkauf, Lager, Bestand, Auffüllung und Verantwortlichkeiten.",
    focus: ["inventory", "movement", "refill", "audit", "roi"],
  },
  investor: {
    label: "Investor View",
    text: "Wiederholbares Workflow-Modell für Gastronomie- und Foodservice-Standorte.",
    focus: ["normalizer", "inventory", "mobile", "audit", "roi"],
  },
  team: {
    label: "Team View",
    text: "Mobile-first: auffüllen, prüfen, notieren, erledigen.",
    focus: ["location", "refill", "mobile", "note"],
  },
  data: {
    label: "Data Model",
    text: "Import, Normalisierung, interne Events und Audit-fähige Datenstruktur.",
    focus: ["foodnotify", "raw", "normalizer", "parsed", "inventory", "audit"],
  },
};

const nodes = [
  {
    id: "foodnotify",
    label: "FoodNotify Mail",
    type: "input",
    x: 8,
    y: 18,
    icon: "✉️",
    lines: ["HTML / PDF / Mail", "purchase_received"],
  },
  {
    id: "purchase",
    label: "PurchaseDocument",
    type: "input",
    x: 29,
    y: 14,
    icon: "📄",
    lines: ["supplierId", "draft → confirmed"],
  },
  {
    id: "raw",
    label: "RawPayloadStore",
    type: "system",
    x: 29,
    y: 39,
    icon: "🗄️",
    lines: ["payload JSON", "sha256 hash"],
  },
  {
    id: "normalizer",
    label: "Normalizer",
    type: "core",
    x: 50,
    y: 27,
    icon: "⚙️",
    lines: ["external → internal", "confidence 0.94"],
  },
  {
    id: "parsed",
    label: "ParsedLineItem",
    type: "core",
    x: 70,
    y: 17,
    icon: "📋",
    lines: ["item · qty · unit", "matched article"],
  },
  {
    id: "inventory",
    label: "InventoryItem",
    type: "core",
    x: 70,
    y: 42,
    icon: "📦",
    lines: ["currentQty", "minQty"],
  },
  {
    id: "location",
    label: "StockLocation",
    type: "app",
    x: 88,
    y: 33,
    icon: "🏪",
    lines: ["Bar / Küche / Lager", "operative area"],
  },
  {
    id: "movement",
    label: "StockMovement",
    type: "core warning",
    x: 50,
    y: 60,
    icon: "🔁",
    lines: ["IN / OUT / ADJUST", "reason tracked"],
  },
  {
    id: "refill",
    label: "RefillTask",
    type: "app warning",
    x: 70,
    y: 66,
    icon: "✅",
    lines: ["open → done", "threshold trigger"],
  },
  {
    id: "mobile",
    label: "Mobile App",
    type: "app",
    x: 88,
    y: 61,
    icon: "📱",
    lines: ["Bottom Nav", "Plus Action"],
  },
  {
    id: "note",
    label: "QuickNote",
    type: "app",
    x: 29,
    y: 75,
    icon: "⚡",
    lines: ["device-local", "optional sync"],
  },
  {
    id: "audit",
    label: "AuditEvent",
    type: "system",
    x: 50,
    y: 82,
    icon: "🛡️",
    lines: ["append-only", "actor · time"],
  },
];

const edges = [
  ["foodnotify", "purchase"],
  ["foodnotify", "raw"],
  ["purchase", "normalizer"],
  ["raw", "normalizer"],
  ["normalizer", "parsed"],
  ["parsed", "inventory"],
  ["inventory", "location"],
  ["inventory", "movement"],
  ["movement", "refill"],
  ["refill", "mobile"],
  ["note", "audit"],
  ["movement", "audit"],
  ["refill", "audit"],
];

function WebappVisualsSection() {
  return (
    <section className="webappVisuals" id="webapp-visuals">
      <div className="visualsIntro">
        <p className="eyebrow">Webapp Preview · Presentation Mockup</p>
        <h2>So sieht der operative Nutzen in der Webapp aus.</h2>
        <p>
          Diese Visuals sind nachgebaute Präsentationsscreens auf Basis der implementierten
          Cockpit-Flächen: Dashboard, mobile Bottom Navigation, Quick Actions, Quick Notes
          und Bar-Refill-Logik. Sie zeigen den erwartbaren Produktnutzen, nicht rohe Screenshots.
        </p>
      </div>

      <div className="visualsGrid">
        <article className="visualCard large">
          <div className="visualHeader">
            <div>
              <span>Manager Screen · nachgebaut</span>
              <h3>Dashboard</h3>
            </div>
            <b>Implementierte Logik · Demo-Daten</b>
          </div>

          <div className="dashboardMock">
            <div className="dashTop">
              <div>
                <small>Dashboard</small>
                <strong>Operativer Überblick</strong>
                <p>Kritische Bestände, Verbrauch, Alerts und offene Aufgaben.</p>
              </div>
              <button>Kritisch</button>
            </div>

            <div className="dashMetrics">
              <div>
                <span>Kritische Artikel</span>
                <b>7</b>
                <small>3 weitere im Warnbereich</small>
              </div>
              <div>
                <span>Artikelbestand</span>
                <b>184</b>
                <small>12 inaktiv</small>
              </div>
              <div>
                <span>Standorte</span>
                <b>9</b>
                <small>8 aktiv</small>
              </div>
              <div>
                <span>Alerts offen</span>
                <b>5</b>
                <small>2 in Review</small>
              </div>
            </div>

            <div className="tableMock">
              <div className="tableTitle">
                <strong>Kritische Bestands-Hotspots</strong>
                <span>Hotspots</span>
              </div>

              <div className="tableRows">
                <div className="tableHead">
                  <span>Artikel</span>
                  <span>Kategorie</span>
                  <span>Bestand</span>
                  <span>Soll</span>
                  <span>Differenz</span>
                </div>
                <div>
                  <span>Cola Zero 0,33</span>
                  <span>Softdrinks klein</span>
                  <span>4 Kisten</span>
                  <span>8</span>
                  <span>-4</span>
                </div>
                <div>
                  <span>Limetten frisch</span>
                  <span>Bar</span>
                  <span>1 kg</span>
                  <span>4</span>
                  <span>-3</span>
                </div>
                <div>
                  <span>Tonic Water</span>
                  <span>Mixer</span>
                  <span>6 Fl.</span>
                  <span>18</span>
                  <span>-12</span>
                </div>
              </div>
            </div>
          </div>
        </article>

        <article className="visualCard phoneVisual">
          <div className="visualHeader compact">
            <div>
              <span>Team Screen · nachgebaut</span>
              <h3>Auffüllliste Bar</h3>
            </div>
          </div>

          <div className="appPhone">
            <div className="phoneHandle" />

            <div className="appPageTitle">
              <b>Auffüllliste Bar</b>
              <small>Tagesliste für Entnahme und Refill</small>
            </div>

            <div className="refillRun">
              <div>
                <span>Aktiver Lauf</span>
                <b>Heute · Bar vorne</b>
              </div>
              <em>open</em>
            </div>

            <div className="refillGroup">
              <span>Softdrinks klein</span>

              <div className="refillItem active">
                <div>
                  <b>Cola Zero 0,33</b>
                  <small>Ziel: 8 · Ist: 4</small>
                </div>
                <button>+2</button>
              </div>

              <div className="refillItem">
                <div>
                  <b>Fanta 0,33</b>
                  <small>Ziel: 6 · Ist: 5</small>
                </div>
                <button>+1</button>
              </div>

              <div className="refillItem done">
                <div>
                  <b>Sprite 0,33</b>
                  <small>Bestätigt</small>
                </div>
                <button>✓</button>
              </div>
            </div>

            <div className="mobileBottomNav">
              <span>Start</span>
              <span>Auffüllen</span>
              <b>+</b>
              <span>Verlauf</span>
              <span>Bestände</span>
            </div>
          </div>
        </article>

        <article className="visualCard">
          <div className="visualHeader compact">
            <div>
              <span>Mobile UX · implementierte Interaktion</span>
              <h3>Quick Actions</h3>
            </div>
          </div>

          <div className="quickActionMock">
            <div className="qaSheet">
              <p>Schnellaktionen</p>
              <button><span>📝</span>Notiz speichern</button>
              <button><span>☑️</span>Checkliste öffnen</button>
              <button><span>🔁</span>Verbrauch buchen</button>
              <button><span>📦</span>Auffüllliste starten</button>
            </div>
          </div>
        </article>

        <article className="visualCard">
          <div className="visualHeader compact">
            <div>
              <span>Device-lokal · implementierte Logik</span>
              <h3>Quick Notes</h3>
            </div>
          </div>

          <div className="quickNoteMock">
            <div className="noteHeader">
              <b>Schnellnotiz</b>
              <span>localStorage</span>
            </div>

            <textarea
              readOnly
              value={"Bar vorne: Cola Zero auffüllen\n- Limetten prüfen\n- Tonic Water nachzählen"}
            />

            <div className="savedNotes">
              <p>Gespeicherte Notizen</p>

              <div>
                <b>Bar-Check Freitag</b>
                <small>3 Punkte · gerade eben</small>
              </div>

              <div>
                <b>Warenannahme Hinweis</b>
                <small>Lieferung mit Differenz</small>
              </div>
            </div>

            <button>Notiz speichern</button>
          </div>
        </article>
      </div>
    </section>
  );
}

function TruthLayerSection() {
  return (
    <section className="truthLayer" aria-label="Produktstand und Präsentationsgrenzen">
      <article className="truthCard confirmed">
        <span>Ist im Repo belegt</span>
        <h3>Implementierte Produktflächen</h3>
        <p>
          Cockpit, Dashboard-Logik, mobile Bottom Navigation, Quick Actions,
          Quick Notes mit localStorage, Bar-Refill-Flow, Inventory-/Procurement-Datenmodell
          und Audit-orientierte Events sind als Produktbasis vorhanden.
        </p>
      </article>

      <article className="truthCard presentation">
        <span>Präsentationsschicht</span>
        <h3>Visualisierte Produktlogik</h3>
        <p>
          Operations Map, Stakeholder-Modi und ROI-Overlay sind bewusst verdichtete
          Erklärmodelle. Sie machen den Nutzen sichtbar, sind aber nicht als 1:1
          App-Screens oder fertige Runtime-Funktionen zu verkaufen.
        </p>
      </article>

      <article className="truthCard validation">
        <span>Nächster Validierungsschritt</span>
        <h3>Pilotdaten statt Annahmen</h3>
        <p>
          Für Investorengespräche sollten echte Vercel-Screenshots, reale Standortdaten,
          FoodNotify-Formatbelege und gemessene Zeit-/Fehlmengenwerte ergänzt werden.
        </p>
      </article>
    </section>
  );
}

export default function App() {
  const [eventKey, setEventKey] = useState("refill");
  const [modeKey, setModeKey] = useState("ceo");
  const [taskDone, setTaskDone] = useState(false);

  const event = events[eventKey];
  const mode = modes[modeKey];

  const roi = useMemo(() => {
    return {
      direct: event.value + event.minutes * 0.3,
      yearly: event.yearly,
    };
  }, [event]);

  const focused = (id) => event.active.includes(id) || mode.focus.includes(id);

  return (
    <main className="page">
      <nav className="topbar">
        <div className="brand">
          <span className="brandMark" />
          <strong>bevero</strong>
        </div>

        <div className="navLinks">
          <a href="#webapp-visuals">Webapp</a>
          <a href="#truth-layer">Einordnung</a>
          <a href="#map">Operations Map</a>
          <a href="#roi">ROI</a>
          <a href="#value">Mehrwert</a>
          <a href="#roadmap">Roadmap</a>
        </div>

        <button className="navCta">Pilot-Demo</button>
      </nav>

      <section className="hero">
        <div className="heroCopy">
          <p className="eyebrow">Investor / CEO Presentation Mockup</p>
          <h1>
            Vom Lieferschein zum Bar-Refill:
            <span> Warenwirtschaft als lebendes Datenmodell.</span>
          </h1>
          <p className="lead">
            Bevero macht operative Warenbewegungen in Gastronomie-Betrieben sichtbar.
            Der aktuelle Stand ist ein validierungsfähiges Cockpit-Fundament:
            Einkauf, Warenannahme, Bestand, Entnahme, Auffüllliste und Audit Trail
            werden zu einem steuerbaren Workflow.
          </p>

          <div className="heroButtons">
            <a href="#webapp-visuals" className="primaryBtn">Webapp ansehen</a>
            <a href="#roi" className="secondaryBtn">ROI simulieren</a>
          </div>

          <div className="stackRow">
            <span>Fastify API</span>
            <span>Next.js Cockpit</span>
            <span>Prisma / Postgres</span>
            <span>Supabase / RLS</span>
            <span>Audit Events</span>
          </div>
        </div>

        <aside className="phoneCard">
          <div className="phone">
            <div className="phoneHandle" />
            <div className="phoneHeader">
              <b>Auffüllliste</b>
              <small>Heute · Bar vorne</small>
            </div>

            <div className="mobileTask urgent">
              <span>Unter Mindestbestand</span>
              <b>Cola Zero 0,33</b>
              <small>+ 2 Kisten auffüllen</small>
            </div>

            <div className="mobileTask">
              <span>Prüfen</span>
              <b>Limetten frisch</b>
              <small>Verbrauch ungewöhnlich hoch</small>
            </div>

            <div className="mobileTask done">
              <span>Erledigt</span>
              <b>Gläserstation</b>
              <small>AuditEvent erzeugt</small>
            </div>

            <div className="mobileNav">
              <span>Start</span>
              <span>Bestand</span>
              <b>+</b>
              <span>Tasks</span>
              <span>ROI</span>
            </div>
          </div>
        </aside>
      </section>

      <section className="kpis">
        <article>
          <span>Operativer Nutzen</span>
          <strong>4 h/Woche</strong>
          <p>weniger Suchzeit, Abstimmung und manuelle Listen pro Standort.</p>
        </article>
        <article>
          <span>Bestandskontrolle</span>
          <strong>2–4 %</strong>
          <p>weniger Fehlkäufe, Schwund und unklare Warenbewegungen.</p>
        </article>
        <article>
          <span>Payback-Logik</span>
          <strong>12–24 Mon.</strong>
          <p>Amortisation durch Zeitersparnis, weniger Fehler und weniger Out-of-Stock.</p>
        </article>
        <article>
          <span>Skalierung</span>
          <strong>Multi-Site</strong>
          <p>Ein Standort validiert Nutzen; mehrere Standorte multiplizieren ihn.</p>
        </article>
      </section>

      <WebappVisualsSection />

      <div id="truth-layer">
        <TruthLayerSection />
      </div>

      <section className="intro">
        <p className="eyebrow">Core Narrative</p>
        <h2>Die Landingpage verkauft nicht Features, sondern operative Klarheit.</h2>
        <p>
          Für Entscheider wird sichtbar, welche Aufgabe die Webapp im Betrieb erfüllt:
          Sie reduziert Blindstellen zwischen Einkauf, Lager, Bar, Küche und Management.
        </p>
      </section>

      <section className="operations" id="map">
        <aside className="controlPanel">
          <h3>Simulation & Events</h3>
          <p>Wähle einen Vorgang und sieh, welche Teile des Systems Wert erzeugen.</p>

          <div className="eventList">
            {Object.entries(events).map(([key, item]) => (
              <button
                key={key}
                className={`eventBtn ${eventKey === key ? "selected" : ""}`}
                onClick={() => setEventKey(key)}
              >
                <span className="check">✓</span>
                <span>
                  <b>{item.title}</b>
                  <small>{item.subtitle}</small>
                </span>
              </button>
            ))}
          </div>

          <div className="logBox">
            <h4>Event Log</h4>
            {event.log.map((item, index) => (
              <p className={index === event.log.length - 1 ? "finalLog" : ""} key={item}>
                {item === "refill_task_open" && taskDone ? "refill_task_done" : item}
              </p>
            ))}
          </div>
        </aside>

        <section className="mapPanel">
          <div className="mapHeader">
            <div>
              <h2>Bevero Operations Map</h2>
              <p>{mode.text}</p>
              <span className="scopePill">
                Visualisiertes Datenmodell · kein 1:1 App-Screenshot
              </span>
            </div>

            <div className="modeTabs">
              {Object.entries(modes).map(([key, item]) => (
                <button
                  key={key}
                  className={modeKey === key ? "selected" : ""}
                  onClick={() => setModeKey(key)}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>

          <div className="mapCanvas">
            <svg className="edgeLayer" viewBox="0 0 100 100" preserveAspectRatio="none">
              {edges.map(([fromId, toId]) => {
                const from = nodes.find((n) => n.id === fromId);
                const to = nodes.find((n) => n.id === toId);
                const active = event.active.includes(fromId) && event.active.includes(toId);

                return (
                  <g key={`${fromId}-${toId}`}>
                    <line
                      x1={from.x + 4}
                      y1={from.y + 3}
                      x2={to.x + 4}
                      y2={to.y + 3}
                      className={active ? "activeEdge" : ""}
                    />
                    {active && (
                      <circle r="0.7" className="flowParticle">
                        <animateMotion
                          dur="2s"
                          repeatCount="indefinite"
                          path={`M ${from.x + 4} ${from.y + 3} L ${to.x + 4} ${to.y + 3}`}
                        />
                      </circle>
                    )}
                  </g>
                );
              })}
            </svg>

            {nodes.map((node) => {
              const isFocused = focused(node.id);
              const isRefill = node.id === "refill";

              return (
                <article
                  key={node.id}
                  className={`mapNode ${node.type} ${isFocused ? "focused" : "dimmed"}`}
                  style={{ left: `${node.x}%`, top: `${node.y}%` }}
                >
                  <div className="nodeTop">
                    <span>{node.icon}</span>
                    <i>{node.type.replace(" warning", "")}</i>
                  </div>

                  <b>{node.label}</b>
                  {node.lines.map((line) => (
                    <small key={line}>{line}</small>
                  ))}

                  {isRefill && (
                    <button className="taskToggle" onClick={() => setTaskDone(!taskDone)}>
                      {taskDone ? "Task wieder öffnen" : "Task erledigt"}
                    </button>
                  )}
                </article>
              );
            })}
          </div>
        </section>

        <aside className="roiPanel" id="roi">
          <div className="roiTitle">
            <span>📈</span>
            <h3>ROI-Simulation</h3>
          </div>

          <div className="roiValue">{roi.direct.toFixed(2)} €</div>
          <small className="roiDisclaimer">
            Annahmenmodell · im Pilotbetrieb mit echten Standortdaten zu validieren
          </small>
          <p>{event.message}</p>

          <div className="roiSplit">
            <div>
              <b>{event.minutes} Min.</b>
              <span>Zeit gespart</span>
            </div>
            <div>
              <b>{roi.yearly.toLocaleString("de-DE")} €</b>
              <span>Jahrespotenzial</span>
            </div>
          </div>

          <div className="benefits">
            <p>✓ weniger manuelle Abstimmung</p>
            <p>✓ weniger unklare Entnahmen</p>
            <p>✓ weniger Out-of-Stock-Risiko</p>
            <p>✓ bessere Entscheidungsdaten</p>
          </div>
        </aside>
      </section>

      <section className="valueGrid" id="value">
        <article>
          <span>🏪</span>
          <h3>Für CEOs & Betreiber</h3>
          <p>
            Ein klarer Blick auf Einkauf, Bestand, Auffüllung, Differenzen und Aufgaben.
            Das ersetzt Bauchgefühl durch operative Steuerbarkeit.
          </p>
        </article>

        <article>
          <span>📊</span>
          <h3>Für Investoren</h3>
          <p>
            Der Wert liegt nicht nur im aktuellen MVP, sondern in einem wiederholbaren
            Prozessmodell für Foodservice-Standorte.
          </p>
        </article>

        <article>
          <span>📱</span>
          <h3>Für Teams</h3>
          <p>
            Mobile-first: Mitarbeiter sehen keine komplexe Warenwirtschaft,
            sondern die nächste relevante Aktion.
          </p>
        </article>
      </section>

      <section className="roiCalc">
        <div>
          <p className="eyebrow">ROI-Beispiel</p>
          <h2>Der Business Case entsteht aus vielen kleinen Verlusten, die jeden Tag passieren.</h2>
          <p>
            Diese Annahmen sind bewusst konservativ und sollten im Pilotbetrieb
            mit echten Standortdaten validiert werden.
          </p>
        </div>

        <div className="bars">
          <div className="barRow">
            <span style={{ width: "68%" }} />
            <b>Arbeitszeit sparen · 3.744 €/Jahr</b>
          </div>
          <div className="barRow">
            <span style={{ width: "45%" }} />
            <b>Fehlkauf / Verderb senken · 1.920 €/Jahr</b>
          </div>
          <div className="barRow">
            <span style={{ width: "56%" }} />
            <b>Out-of-Stock vermeiden · 2.500 €/Jahr</b>
          </div>

          <div className="totalBox">
            <span>Konservativer Nutzen pro Standort</span>
            <strong>≈ 8.164 €/Jahr</strong>
          </div>
        </div>
      </section>

      <section className="roadmap" id="roadmap">
        <div className="roadmapIntro">
          <p className="eyebrow">Produktstand & Roadmap</p>
          <h2>Für die Präsentation zählt Ehrlichkeit: Was ist da, was wird validiert, was skaliert?</h2>
        </div>

        <div className="timeline">
          <article>
            <span>01 · Heute</span>
            <h3>Technisches Fundament</h3>
            <p>API, Cockpit, Datenmodell, Import-/Normalisierungslogik, mobile UI-Patterns und Audit-Konzept.</p>
          </article>
          <article className="active">
            <span>02 · Präsentation</span>
            <h3>Investor Landingpage</h3>
            <p>Operations Map, ROI-Simulation und Stakeholder-Perspektiven machen den Nutzen greifbar, ohne Runtime-Reife zu überzeichnen.</p>
          </article>
          <article>
            <span>03 · Pilot</span>
            <h3>Restaurantbetrieb validieren</h3>
            <p>Echte Abläufe messen: Zeitersparnis, Fehlmengen, Auffüllqualität und Akzeptanz im Team.</p>
          </article>
          <article>
            <span>04 · Skalierung</span>
            <h3>Multi-Location Playbook</h3>
            <p>Onboarding, Rollenmodell, Standard-Integrationen und wiederholbare Standort-Rollouts.</p>
          </article>
        </div>
      </section>
    </main>
  );
}
