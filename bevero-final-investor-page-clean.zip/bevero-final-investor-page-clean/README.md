# Bevero Final Investor & CEO Präsentationspage — Clean Version

Vollständiges React/Vite-Bundle für eine Landingpage, die den Mehrwert der Bevero-Webapp visualisiert, aber bewusst sauber zwischen Ist-Zustand, Präsentationsvisualisierung und Validierungsbedarf trennt.

## Inhalt

- Hero mit Investor-/CEO-Narrativ
- KPI-Leiste
- Webapp-Preview mit Dashboard, Auffüllliste, Quick Actions und Quick Notes
- Truth Layer: Was ist im Repo belegt, was ist Präsentationsschicht, was muss validiert werden
- Interaktive Operations Map
- Modi: CEO View, Investor View, Team View, Data Model
- Event-Simulationen: FoodNotify-Import, Fehlmenge, Bar-Refill
- ROI-Simulation mit Validierungshinweis
- Mehrwert-Sektion für Betreiber, Investoren und Teams
- ROI-Beispielrechnung
- Produktstand & Roadmap
- Vercel-ready `vercel.json`

## Starten

```bash
npm install
npm run dev
```

Dann die lokale Vite-URL öffnen.

## Build

```bash
npm run build
npm run preview
```

## Vercel

Dieses Bundle kann direkt als Vite-Projekt auf Vercel importiert werden.

Empfohlene Settings:

```text
Framework Preset: Vite
Build Command: npm run build
Output Directory: dist
Install Command: npm install
Root Directory: ./
```

## Dateien

- `package.json`
- `index.html`
- `vercel.json`
- `.gitignore`
- `src/main.jsx`
- `src/App.jsx`
- `src/styles.css`

## Hinweis

Die Webapp-Visuals sind presentation-ready Mockups, die implementierte Cockpit-Flächen und Produktlogiken verdichten. ROI und Operations Map sind bewusst als Simulation bzw. visualisierte Produktlogik gekennzeichnet.
# beverolanding
